package com.mycompany.firstproject;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Pattern;
import javax.lang.model.SourceVersion;
import javax.swing.JOptionPane;

public class Firstproject {

    public static void main(String[] args) {
        // Username input and validation
        try (Scanner sc = new Scanner(System.in)) {
            // Username input and validation
            String name;
            System.out.print("Please enter your name (should contain an underscore and be more than 5 characters): ");
            name = sc.next();
            boolean isUsernameValid = false;  // Track if the username is valid
            if (name.length() > 5 && name.contains("_")) {
                System.out.println("Username successfully captured");
                isUsernameValid = true;
            } else {
                System.out.println("Username is not correctly formatted. Please ensure that your username contains an underscore and is more than 5 characters in length.");
            }   // Password input and validation
            String password;
            System.out.print("Please enter your password (at least 8 characters, with a capital letter, a number, and a special character): ");
            password = sc.next();
            boolean isPasswordValid = validatePassword(password);  // Track if the password is valid
            if (isPasswordValid) {
                System.out.println("Password successfully captured");
            } else {
                System.out.println("Password is not correctly formatted. Please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character.");
            }   // Final login success or failure message
            if (isUsernameValid && isPasswordValid) {
                System.out.println("Logged in successfully");
            } else {
                System.out.println("Failed to log in");
            }
            // Closing scanner to avoid resource leak
        }
    }

    // Password validation method
    public static boolean validatePassword(String password) {
        if (password.length() < 8) {
            return false; // Password should be at least 8 characters long
        }

        boolean hasUppercase = false;
        boolean hasNumber = false;
        boolean hasSpecialChar = false;

        // Define the special characters allowed
        String specialCharacters = "!@#$%^&*";

        // Loop through each character in the password
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                hasUppercase = true;
            } else if (Character.isDigit(c)) {
                hasNumber = true;
            } else if (specialCharacters.contains(Character.toString(c))) {
                hasSpecialChar = true;
            }

            // If all conditions are met, return true
            if (hasUppercase && hasNumber && hasSpecialChar) {
                return true;
            }
        }

        // Return false if any condition is not met
        return false;
    }
    public SourceVersion getSupportedSourceVersion() {
        return SourceVersion.latest();
    }
} 
//POE part 2
public class Firstproject2 {

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");
        LoginRegistration app = new LoginRegistration();
        app.run();
    }
}

class LoginRegistration {
    private boolean loginValid = false;
    private final ArrayList<Task> tasks = new ArrayList<>();

    public void run() {
        while (true) {
            String choice = JOptionPane.showInputDialog("Option 1) Login\nOption 2) Register\nOption 3) Quit");
            if (choice.equals("1")) {
                login();
                if (loginValid) {
                    taskManagementLoop();
                }
            } else if (choice.equals("2")) {
                registerUser();
            } else if (choice.equals("3")) {
                System.exit(0);
            }
        }
    }

    //Enter personal details to login
    private void login() {
        // Login with validation
        String username = JOptionPane.showInputDialog("Enter username:");//Username must be 50 characters and less
        String password = JOptionPane.showInputDialog("Enter password:");//Password must not exceed 8 characters

        if (validateUsername(username) && validatePassword(password)) {
            loginValid = true;
            JOptionPane.showMessageDialog(null, "Login successful!");
        } else {
            loginValid = false;
            JOptionPane.showMessageDialog(null, "Login failed. Please check your username and password format.");
        }
    }

    private void registerUser() {
        // Registration simulation
        JOptionPane.showMessageDialog(null, "Registration feature coming soon.");
    }

    private void taskManagementLoop() {
        while (loginValid) {
            String choice = JOptionPane.showInputDialog("""
                Option 1) Add tasks
                Option 2) Show report
                Option 3) Quit
            """);
            switch (choice) {
                case "1" -> addTasks();
                case "2" -> JOptionPane.showMessageDialog(null, "Coming Soon.");
                case "3" -> System.exit(0);
                default -> JOptionPane.showMessageDialog(null, "Invalid option. Please try again.");
            }
        }
    }

    private void addTasks() {
        int numOfTasks = Integer.parseInt(JOptionPane.showInputDialog("How many tasks do you wish to enter?"));
        for (int i = 0; i < numOfTasks; i++) {
            String name = JOptionPane.showInputDialog("Enter the name of task " + (i + 1));
            String description = JOptionPane.showInputDialog("Enter task description:");
            String developer = JOptionPane.showInputDialog("Enter developer name:");
            int duration = Integer.parseInt(JOptionPane.showInputDialog("Enter duration of task in hours:"));
            String status = JOptionPane.showInputDialog("Enter status (e.g., To Do, In Progress, Done):");

            tasks.add(new Task(name, description, developer, duration, status));
            JOptionPane.showMessageDialog(null, "Task added: " + name);
        }
    }

    private boolean validateUsername(String username) {
        if (username.contains("_") && username.length() <= 5) {
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.");
            return false;
        }
    }

    private boolean validatePassword(String password) {
        // Regex to check password complexity
        String passwordPattern = "^(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$";
        if (Pattern.matches(passwordPattern, password)) {
            JOptionPane.showMessageDialog(null, "Password successfully captured");
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character.");
            return false;
        }
    }
}

class TaskClass {
   
    private final String taskName;
    private String taskID;
    private String taskDescription;
    private final int duration;
    private final String devDetails;
    private final String taskNumber;
    private final int total;
    private String status;
    private final int count;
    private final int taskStatus;
    private final int optionSelect;
    private String taskDetails;

    public TaskClass(String taskName,String taskDetails, String taskID,int optionSelect, String taskDescription, int duration, String devDetails, String taskNumber, int total, String status, int count,int taskStatus) {
    
        this.taskName = taskName;
        this.taskID = taskID;
        this.taskDescription = taskDescription;
        this.duration = duration;
        this.devDetails = devDetails;
        this.taskNumber = taskNumber;
        this.total = total;
        this.status = status;
        this.count = count;
        this.taskStatus = taskStatus;
        this.optionSelect = optionSelect;
        this.taskDetails = taskDetails;
    }
    public boolean checkTaskDescription() 
    {
       while (taskDescription.length()> 50){
           {
               taskDescription = JOptionPane.showInputDialog("Please enter the task Description.It may not exceed 50 Characters");
           }
       return true; 
    
       }
        return false; 
    
        //POE part 2
    public String createTaskID() 
    {
        taskID = (taskName.substring(0, 2) + ":" + count + ":" + devDetails.substring(devDetails.length() - 3) );
        taskID = taskID .toUpperCase();
        return taskID;
    }

    public String printTaskDetails() 
    {
        if (taskStatus == 1)//The ifs help the computer decide between one of the three options by receiving user input//
        {
            status = ("TO DO");
        }
        if (taskStatus == 2)
        {
            status = ("DONE");
        }
        if (taskStatus == 3);
        {
            status = ("DOING");
        }
        taskDetails = (status + "," + devDetails + "," + count + "," + taskName + "," + taskDescription + "," + taskID + "," + duration);
        //This line of code brings everything together to make the task details list
        return taskDetails;
    }
    
    public int returnTotalHours() 
    {
        int total = 0;
        if (count == 0)
        {
            total = duration;
        }
        else if (count >= 1)
        {
            total = total+duration;
        }
        return total;
    }
}

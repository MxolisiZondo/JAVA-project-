/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.firstproject;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class Firstproject2Test {
    
    public Firstproject2Test() {
    }
    

public class TaskClassTest {
    
    private TaskClass task;

    @BeforeEach
    public void setUp() {
        task = new TaskClass("TaskName", "TaskDetails", "TN:0:XYZ", 1, "This is a task description", 5, "DeveloperDetails", "TaskNumber", 10, "TO DO", 0, 1);
    }

    @Test
    public void testCheckTaskDescription_Valid() {
        // Set a valid description
        task.checkTaskDescription();
        // Assuming the description is valid, we expect it to be less than or equal to 50 characters
        assertTrue(task.checkTaskDescription());
    }

    @Test
    public void testCheckTaskDescription_Invalid() {
        // Set an invalid description
        task = new TaskClass("TaskName", "TaskDetails", "TN:0:XYZ", 1, "This is a task description that is way too long and exceeds fifty characters", 5, "DeveloperDetails", "TaskNumber", 10, "TO DO", 0, 1);
        assertFalse(task.checkTaskDescription());
    }

    @Test
    public void testCreateTaskID() {
        String expectedTaskID = "TA:0:TLS"; // Based on the initial setup
        assertEquals(expectedTaskID, task.createTaskID());
    }

    @Test
    public void testPrintTaskDetails() {
        String expectedDetails = "TO DO,DeveloperDetails,0,TaskName,This is a task description,TN:0:XYZ,5";
        assertEquals(expectedDetails, task.printTaskDetails());
    }

    @Test
    public void testReturnTotalHours_NoCount() {
        assertEquals(5, task.returnTotalHours()); // Since count is 0, it should return duration
    }

    @Test
    public void testReturnTotalHours_WithCount() {
        task = new TaskClass("TaskName", "TaskDetails", "TN:0:XYZ", 1, "This is a task description", 5, "DeveloperDetails", "TaskNumber", 10, "TO DO", 2, 1);
        assertEquals(10, task.returnTotalHours()); // Since count is 2, it should return duration * count
    }
}

    /**
     * Test of main method, of class Firstproject2.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Firstproject2.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
